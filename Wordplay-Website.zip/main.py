from flask import Flask, render_template, request
import random
import json


from libraries.wordle_solver_code import *
from libraries.word_finder_solver import *
from libraries.spelling_bee_solver_code import *

app = Flask(__name__, template_folder='templates')

# Home Page
@app.route("/home", methods=('GET', 'POST'))
def home():
  return render_template('home.html')

@app.route("/", methods=('GET', 'POST'))
def home1():
  return render_template('home.html')

# Wordle Solver
@app.route("/wordle", methods=('GET', 'POST'))
def wordle():
  green = ""
  yellow = ""
  gray = ""
  matches = []

  if request.method == "POST":
      green = request.form["greenLetters"]
      yellow = request.form["yellowLetters"]
      gray = request.form["grayLetters"]

      ugG = green
      ugy0 = yellow
      ugB = gray

      ugy0 = unspecificLetterWords(ugy0)
      ugG = specificLetterWords(ugG)

      matches = set(ugG).intersection(ugy0)
      matches = invalidLetterChecker(list(matches), ugB)

      print(request.form)
  return render_template("wordle_index.html",
                         greenInput=green,
                         yellowInput=yellow,
                         grayInput=gray,
                         potentialWordsAmount=len(matches),
                         potentialWords=matches)

# Spelling Bee Solver
@app.route("/sbee", methods=('GET', 'POST'))
def sBee():
  letters = ""
  wordList = []

  if request.method == "POST":
      letters = request.form["letters"]

      wordList = wordFinder(letters)

      print(request.form)
  return render_template("spelling_bee_index.html",
                         lettersInput=letters,
                         potentialWordsAmount=len(wordList),
                         potentialWords=wordList)

# Word Finder
@app.route("/wordfinder", methods=('GET', 'POST'))
def wordFinder():
  reqInputLetters = ""
  unreqInputLetters = ""
  inputComparison = ""
  inputSize = ""
  
  wordList = []

  if request.method == "POST":
      
      reqInputLetters = request.form["reqLetters"]
      unreqInputLetters = request.form["unreqLetters"]
    
      inputComparison = request.form["compOp"]
      inputSize = request.form["compLen"]
    
      U_wordList = unspecificWordFinder(unreqInputLetters, inputSize, inputComparison)
      S_wordList = specificWordFinder(reqInputLetters, inputSize, inputComparison)
    
      wordList = set(S_wordList).intersection(U_wordList)

      print(request.form)
  return render_template("word_finder_index.html",
                         reqInput=reqInputLetters,
                         unreqInput=unreqInputLetters,
                         compOpInput=inputComparison,
                         compLenInput=inputSize,
                         
                         potentialWordsAmount=len(wordList),
                         potentialWords=wordList)

if __name__ == "__main__":
    app.run(  # Starts the site
        host=
        '0.0.0.0',  # Establishes the host, required for repl to detect the site
        port=random.randint(
            2000, 9000)  # Randomly select the port the machine hosts on.
    )
