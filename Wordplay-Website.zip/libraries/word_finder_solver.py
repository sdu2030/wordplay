# Function of program: To cheese the NYTimes spelling bee puzzle
# https://www.nytimes.com/puzzles/spelling-bee
# Date: 4/14/2022

with open("dictionary.txt", "r") as f:
    words = f.readlines()


def unspecificWordFinder(letterList, length, compare):

    potentialWords = []

    for word in words:
        word = word.rstrip()

        if compare == "==":
            if len(word) != int(length):
                continue
        elif compare == "!=":
            if len(word) == int(length):
                continue
        elif compare == ">":
            if len(word) <= int(length):
                continue
        elif compare == "<":
            if len(word) >= int(length):
                continue

        # Checks if specified letters are in the word
        contains = 0
        for i in range(len(list(word))):
            if word[i] in letterList:
                contains += 1

        if (contains == len(letterList)):
            potentialWords.append(word)

    return potentialWords


def specificWordFinder(letterList, length, compare):

    potentialWords = []

    for word in words:
        word = word.rstrip()

        if compare == "==":
            if len(word) != int(length):
                continue
        if compare == "!=":
            if len(word) == int(length):
                continue
        if compare == ">":
            if len(word) <= int(length):
                continue
        if compare == "<":
            if len(word) >= int(length):
                continue

        # Checks if specified letters are in the word
        try:
            contains = True
            i = 0
            while i < len(list(letterList)):
                if letterList[i].isalpha():
                    if word[i] != letterList[i]:
                        contains = False
                i += 1

            if contains:
                potentialWords.append(word)
        except:
            pass

    return potentialWords


# Input
if __name__ == "__main__":
    while True:
        reqInputLetters = input("Input specifc letters, with spaces: ").lower()
        unreqInputLetters = input("Input any letters: ").lower()

        inputComparison = input(
            "Input the comparison operator used to determine the size of the word (==, !=, <, >,): "
        )
        inputSize = input("How large/small? ")

        U_wordList = unspecificWordFinder(unreqInputLetters, inputSize,
                                          inputComparison)
        S_wordList = specificWordFinder(reqInputLetters, inputSize,
                                        inputComparison)

        wordList = set(S_wordList).intersection(U_wordList)

        print()
        print(str(len(list(wordList))) + " satisfactory words found.")
        print(list(wordList))

        if input("\n\nEnter [q] to exit.\n").lower() == "q":
            break
